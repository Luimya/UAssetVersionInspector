UAsset Version Inspector

用法：
1. 双击 UAssetVersionInspector.exe。
2. 点击“选择 .uasset”，或把 .uasset 文件拖进窗口。
3. 查看 UE 保存版本、兼容版本、资源路径、依赖路径和缺失提示。

注意：
- 这个工具只读取文件，不会修改 .uasset。
- 当前版本是 .NET 9 Windows 桌面版，适合这台机器直接运行。
- 如果复制到其他电脑，需要那台电脑安装 .NET 9 Desktop Runtime。
- 移动工具时请移动整个 UAssetVersionInspector 文件夹，或使用 zip 包。

隐藏批处理模式：
UAssetVersionInspector.exe --report-file report.txt MyAsset.uasset
